import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\selenium\\chromedriver.exe");
        System.out.println("Hi Hello");
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        
    
        
        driver.get("http://localhost/ManpowerFinal");
        driver.manage().window().maximize();
        System.out.println(driver.getTitle());
        Thread.sleep(2000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(1000);
        driver.findElement(By.name("nameL")).click();
        Thread.sleep(200);
        driver.findElement(By.name("nameL")).clear();
        Thread.sleep(1000);
        driver.findElement(By.name("nameL")).sendKeys("C214748364");
        Thread.sleep(200);
        driver.findElement(By.name("pwdL")).click();
        Thread.sleep(200);
        driver.findElement(By.name("pwdL")).clear();
        Thread.sleep(200);
        driver.findElement(By.name("pwdL")).sendKeys("1234");
        Thread.sleep(1000);
        driver.findElement(By.name("pwdL")).sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        try {

            driver.switchTo().alert();
            driver.switchTo().alert().accept();
            WebDriverWait wait = new WebDriverWait(driver, 30);
            // Wait for Alert to be present
            Alert myAlert = wait.until(ExpectedConditions.alertIsPresent());

            myAlert.accept();



        }


        catch (org.openqa.selenium.NoAlertPresentException e){
            driver.navigate().refresh();

        }
       System.out.println("SD");
        }
        
	
	
	
	

}
